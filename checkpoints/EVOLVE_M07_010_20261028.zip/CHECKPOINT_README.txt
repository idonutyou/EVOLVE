M07 10% INCREMENTAL ONLY. Full tree restore branch backup/monetization-m07-010-20261028. No runtime changes, no new rendered images. Previous backups are retained.

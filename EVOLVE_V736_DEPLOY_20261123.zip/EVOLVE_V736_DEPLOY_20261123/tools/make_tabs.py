"""파츠 탭이 켜진 탭 줄 그림: 코어 도감 참조 그림(941x1672)의 탭 줄을 그대로 쓰되
1번 탭(코어)은 꺼진 모양, 2번 탭(파츠)은 켜진 모양으로 바꾼다. 글자는 참조 그림의 글자 자체를 색만 바꿔 옮긴다.
2번 탭 숫자는 비워 둔다(게임이 실제 개수를 글자로 그림). 결과: art/tabs_parts.png (참조 좌표 x20..910, y334..442)"""
import sys
sys.path.insert(0, '/home/claude/work/tools')
from PIL import Image
import numpy as np, cv2
from harmonic import harmonic_fill

REF = '/home/claude/idonutyou/evolve/assets/3c8e640c2bcb81636ce7690e1c5c528a66dee56c7923aa6fe15964ac60409daa.png'
ref = np.array(Image.open(REF).convert('RGB')).astype(np.float64)
X0, Y0, X1, Y1 = 20, 334, 910, 442
O = ref[Y0:Y1, X0:X1].copy()            # original strip
h, w, _ = O.shape
P = 204                                  # tab pitch (measured: inactive tab2 285..477)


def L(a):
    return a.mean(axis=2)


# 1) text-free faces: fill the text boxes of all four tabs
F = O.copy()
# tab1 (active teal face): row-wise linear fill keeps its vertical gradient
for yy in range(366 - Y0, 406 - Y0):
    a, b = 126 - X0, 234 - X0
    l = O[yy, a - 3:a].mean(axis=0); r = O[yy, b:b + 3].mean(axis=0)
    t = np.linspace(0, 1, b - a)[:, None]
    F[yy, a:b] = l * (1 - t) + r * t
# tab2 (inactive face): harmonic fill. Tabs 3 and 4 keep their printed text.
m = np.zeros((h, w), bool)
m[366 - Y0:406 - Y0, 332 - X0:432 - X0] = True
F = harmonic_fill(F, m)

# 2) glyph alphas
# white glyphs on the teal tab1 (코어 + 12)
aw = np.clip((L(O) - L(F)) / np.maximum(255 - L(F), 1), 0, 1)
win = np.zeros((h, w), bool); win[366 - Y0:406 - Y0, 126 - X0:234 - X0] = True
aw[~win] = 0
# dark glyphs on the light tab2 (파츠 + 20)
TEXT = np.array([28, 50, 76], float)     # label colour of inactive tabs (sampled below)
dwin = np.zeros((h, w), bool); dwin[366 - Y0:406 - Y0, 332 - X0:432 - X0] = True
ys, xs = np.nonzero(dwin & (L(O) < 90))
TEXT = O[ys, xs].mean(axis=0)
ad = np.clip((L(F) - L(O)) / np.maximum(L(F) - TEXT.mean(), 1), 0, 1)
ad[~dwin] = 0
# count colour of inactive tabs: pixels of "20" (x 403..426)
cwin = np.zeros((h, w), bool); cwin[366 - Y0:406 - Y0, 401 - X0:430 - X0] = True
ys, xs = np.nonzero(cwin & (ad > 0.85))
COUNT = O[ys, xs].mean(axis=0)
ys, xs = np.nonzero((~cwin) & dwin & (ad > 0.85))
LABEL = O[ys, xs].mean(axis=0)
print('label', LABEL.round(), 'count', COUNT.round())

# 3) background behind the old active tab (+glow): smooth fill, then paste an inactive tab there
N = F.copy()
m = np.zeros((h, w), bool)
m[338 - Y0:438 - Y0, 62 - X0:286 - X0] = True
N = harmonic_fill(N, m)


def octagon_mask(x0, y0, x1, y1, c, feather):
    """anti-aliased chamfered rectangle mask in strip coordinates"""
    S = 4
    big = np.zeros((h * S, w * S), np.uint8)
    pts = np.array([[x0 + c, y0], [x1 - c, y0], [x1, y0 + c], [x1, y1 - c], [x1 - c, y1], [x0 + c, y1], [x0, y1 - c], [x0, y0 + c]], float)
    pts = ((pts - [X0, Y0]) * S).astype(np.int32)
    cv2.fillPoly(big, [pts], 255)
    small = cv2.resize(big, (w, h), interpolation=cv2.INTER_AREA).astype(np.float64) / 255
    if feather:
        small = np.clip(cv2.GaussianBlur(small, (0, 0), feather) * 1.15, 0, 1) if feather > 0 else small
    return small


# inactive tab silhouette (tab2 measured 285..477 x 352..422, chamfer ~13) incl. border+shadow
mi = octagon_mask(283, 350, 479, 425, 14, 1.2)
src = np.roll(F, -P, axis=1)            # clean inactive tab2 moved onto tab1
mi1 = np.roll(mi, -P, axis=1)
N = N * (1 - mi1[:, :, None]) + src * mi1[:, :, None]

# 4) active tab (clean) moved onto tab2: silhouette 68..284 x 344..428 + cyan glow
ma = octagon_mask(66, 343, 286, 429, 17, 2.2)
srcA = np.roll(F, P, axis=1)
ma2 = np.roll(ma, P, axis=1)
N = N * (1 - ma2[:, :, None]) + srcA * ma2[:, :, None]

# 5) glyphs: 코어/12 (dark) onto tab1, 파츠 (white) onto tab2 — same places as printed
aw_k = aw.copy()                         # 코어 + 12 (white on teal originally)
lab_k = aw_k.copy(); lab_k[:, 190 - X0:] = 0          # 코어 only (x<190)
cnt_k = aw_k.copy(); cnt_k[:, :190 - X0] = 0          # 12
for a, col in ((lab_k, LABEL), (cnt_k, COUNT)):
    N = N * (1 - a[:, :, None]) + col * a[:, :, None]
ad_p = ad.copy(); ad_p[:, 396 - X0:] = 0                 # 파츠 only (no 20)
WHITE = np.array([255, 255, 255], float)
N = N * (1 - ad_p[:, :, None]) + WHITE * ad_p[:, :, None]

out = np.clip(N, 0, 255).astype(np.uint8)
Image.fromarray(out).save('/home/claude/work/art/tabs_parts.png')
big = Image.fromarray(out).resize((w * 2, h * 2), Image.LANCZOS)
cmp = Image.new('RGB', (w * 2, h * 4 + 10), 'white')
cmp.paste(Image.fromarray(O.astype(np.uint8)).resize((w * 2, h * 2), Image.LANCZOS), (0, 0)); cmp.paste(big, (0, h * 2 + 10))
cmp.save('/home/claude/work/shots/tabs_compare.png')
print('saved', out.shape)

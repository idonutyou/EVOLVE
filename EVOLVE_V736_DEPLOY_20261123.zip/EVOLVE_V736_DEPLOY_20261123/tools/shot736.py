"""V736 도감 확인: python3 shot736.py <base_url> <out_dir> <w> <h> [detail_ids...]
코어 목록·코어 상세(회귀), 파츠 목록, 파츠 상세(카드 눌러 열기), 닫기·X·뒤로(Escape) 동작을 확인한다."""
import sys, json, asyncio
from playwright.async_api import async_playwright

base, out = sys.argv[1], sys.argv[2]
W, H = int(sys.argv[3]), int(sys.argv[4])
ids = sys.argv[5:] or ['basic_cannon']


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox', '--use-gl=swiftshader'])
        ctx = await b.new_context(viewport={'width': W, 'height': H}, device_scale_factor=2, is_mobile=True, has_touch=True, locale='ko-KR')
        page = await ctx.new_page()
        errs = []
        page.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)[:300]))
        page.on('console', lambda m: errs.append('console.' + m.type + ': ' + m.text[:200]) if m.type == 'error' else None)
        page.on('requestfailed', lambda r: errs.append('requestfailed: ' + r.url[-80:]))
        await page.goto(base + '/index.html?evolveUIPage=codex', wait_until='load', timeout=180000)
        await page.wait_for_function("document.querySelector('#codexContent .dex01')!==null", timeout=180000)
        await page.wait_for_timeout(2500)
        res = {}
        await page.screenshot(path=f'{out}/core_list.png')
        await page.evaluate("document.querySelector(`[data-dex-tab='parts']`).click()")
        await page.wait_for_timeout(1500)
        await page.screenshot(path=f'{out}/parts_list.png')
        res['cards'] = await page.evaluate("[...document.querySelectorAll('#codexContent button.claudePartRec')].map(b=>b.getAttribute('aria-label'))")
        res['groups'] = await page.evaluate("[...document.querySelectorAll('#codexContent .dex01Group>h3')].map(h=>h.textContent)")
        res['tabcounts'] = await page.evaluate("[...document.querySelectorAll('#codexContent .dex01Count')].map(c=>c.textContent+':'+c.dataset.referenceMatch)")
        for i, pid in enumerate(ids):
            await page.evaluate("id=>document.querySelector(`#codexContent [data-dex-card='part:${id}']`).click()", pid)
            await page.wait_for_timeout(1300)
            await page.screenshot(path=f'{out}/detail_{pid}.png')
            res['open_' + pid] = await page.evaluate("window.__CLAUDE_CODEX_PARTS__.read().open")
            how = ['close', 'x', 'escape'][i % 3]
            if how == 'close':
                await page.evaluate("document.querySelector('#claudePartDetail .cpdClose').click()")
            elif how == 'x':
                await page.evaluate("document.querySelector('#claudePartDetail .cpdX').click()")
            else:
                await page.keyboard.press('Escape')
            await page.wait_for_timeout(500)
            res['after_' + how] = await page.evaluate("({open:window.__CLAUDE_CODEX_PARTS__.read().open,page:document.getElementById('poster').dataset.homePage,tab:document.querySelector('#codexContent .dex01')?.dataset.category})")
        # core detail regression
        await page.evaluate("document.querySelector(`[data-dex-tab='core']`).click()")
        await page.wait_for_timeout(800)
        await page.evaluate("document.querySelector('#codexContent [data-dex-card]').click()")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=f'{out}/core_detail.png')
        res['read'] = await page.evaluate("window.__CLAUDE_CODEX_PARTS__.read()")
        res['errors'] = errs
        print(json.dumps(res, ensure_ascii=False, indent=1))
        await b.close()

asyncio.run(main())

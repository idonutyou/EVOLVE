"""상세 바탕 그림: 진열장 정리본(chamber_clean2.png)에서 무기별로 바뀌는 글자·수치·레이더를 지운다.
지운 자리는 주변 바탕에서 부드럽게 이어 채운다(harmonic fill). 결과: art/detail_template_full.png"""
import sys
sys.path.insert(0, '/home/claude/work/tools')
from PIL import Image
import numpy as np, cv2
from harmonic import harmonic_fill

im = np.array(Image.open('/home/claude/work/art/chamber_clean2.png').convert('RGB')).astype(np.float64)
H, W, _ = im.shape
regions = []
# info card: pills (+separator), old name, description
regions += [('rect', 36, 816, 390, 864), ('rect', 50, 876, 266, 931), ('rect', 56, 947, 890, 1005)]
# bars + values, six rows
for top, bot in [(1107, 1125), (1153, 1169), (1198, 1214), (1242, 1259), (1289, 1305), (1333, 1350)]:
    regions.append(('rect', 596, top - 5, 904, bot + 5))
# footer values: FILE_NO, SLOT, STATUS (icon + text)
regions += [('rect', 70, 1427, 150, 1459), ('rect', 366, 1427, 430, 1459), ('rect', 510, 1424, 702, 1461)]
# whole radar block (hexagon + its six labels) — redrawn live
regions.append(('rect', 46, 1094, 404, 1380))
# radar hexagon (pointy top), centre (230,1235)
cx, cy, r = 230.0, 1235.0, 113.0
hexpts = np.array([[cx + r * np.cos(np.radians(a)), cy + r * np.sin(np.radians(a))] for a in (-90, -30, 30, 90, 150, 210)], np.int32)

mask = np.zeros((H, W), np.uint8)
for kind, x0, y0, x1, y1 in regions:
    mask[y0:y1, x0:x1] = 1
mask = mask.astype(bool)

# fill each connected region separately (small linear systems)
n, lab = cv2.connectedComponents(mask.astype(np.uint8), connectivity=4)
out = im.copy()
for i in range(1, n):
    ys, xs = np.nonzero(lab == i)
    y0, y1, x0, x1 = ys.min() - 3, ys.max() + 4, xs.min() - 3, xs.max() + 4
    sub = out[y0:y1, x0:x1]
    sm = lab[y0:y1, x0:x1] == i
    out[y0:y1, x0:x1] = harmonic_fill(sub, sm)

# keep a little of the panel's fine grain so the patches do not look plastic
Y = im.mean(axis=2)
hp = Y - cv2.GaussianBlur(Y, (0, 0), 2.0)
calm = ~mask & (np.abs(hp) < 6)
rs = 1.4826 * np.median(np.abs(hp[calm][::7]))
rng = np.random.default_rng(11)
g = cv2.GaussianBlur(rng.normal(0, 1, (H, W)), (0, 0), 0.6)
g *= (rs * 0.8) / g.std()
out[mask] += g[mask][:, None]
out = np.clip(out, 0, 255).astype(np.uint8)
Image.fromarray(out).save('/home/claude/work/art/detail_template_full.png')
print('grain', round(float(rs), 2), 'regions', n - 1)
Image.fromarray(out[780:1500]).save('/home/claude/work/shots/template_bottom.png')

"""코어 탭 목록 디자인 규칙을 파츠 탭용으로 복제한다(상세 창 규칙은 제외).
python3 gen_parts_css.py <index.html> <out.css>"""
import re, sys

SRC, OUT = sys.argv[1], sys.argv[2]
html = open(SRC, encoding='utf-8').read()
BLOCKS = ['evolveDexCardSizeFixV1', 'evolveCoreLabV712', 'evolveOriginalReferenceCodex', 'evolveLabUnifiedV724', 'claudeUiFixV725']
SKIP = ['dex01Detail', 'dex01CoreDetail', 'coreStats', 'coreRadar', 'coreStat', 'referenceWater', 'referenceBubbles',
        'dex01Close', 'dex01Done', 'dex01Eyebrow', 'dex01ScaleInset', 'refStatsExact', 'refTextExact', 'refOwnership',
        'corePremium', 'gp05QAControlsV662', 'DetailSurface', 'DetailArt', 'coreBase']
KEY = 'data-category="core"'


def strip_comments(css):
    return re.sub(r'/\*.*?\*/', '', css, flags=re.S)


def parse(css):
    """yield (prelude, body, is_at) for top-level items; nested @media bodies are parsed recursively"""
    i, n = 0, len(css)
    out = []
    while i < n:
        j = css.find('{', i)
        if j < 0:
            break
        prelude = css[i:j].strip()
        depth, k = 1, j + 1
        while k < n and depth:
            if css[k] == '{': depth += 1
            elif css[k] == '}': depth -= 1
            k += 1
        body = css[j + 1:k - 1]
        out.append((prelude, body))
        i = k
    return out


def split_selectors(sel):
    parts, depth, cur = [], 0, ''
    for ch in sel:
        if ch == '(': depth += 1
        elif ch == ')': depth -= 1
        if ch == ',' and depth == 0:
            parts.append(cur); cur = ''
        else:
            cur += ch
    parts.append(cur)
    return [p.strip() for p in parts if p.strip()]


def convert_rule(prelude, body):
    sels = [s for s in split_selectors(prelude) if KEY in s]
    keep = []
    for s in sels:
        outside = re.sub(r':is\([^()]*\)', '', s)
        if any(k in outside for k in SKIP):
            continue
        keep.append(s.replace(KEY, 'data-category="parts"'))
    if not keep:
        return None
    return ',\n'.join(keep) + '{' + body.strip() + '}'


out_lines, total = [], 0
for bid in BLOCKS:
    m = re.search(r'<style id="' + bid + r'">(.*?)</style>', html, re.S)
    assert m, bid
    css = strip_comments(m.group(1))
    for prelude, body in parse(css):
        if prelude.startswith('@'):
            inner = [convert_rule(p, b) for p, b in parse(body) if KEY in p]
            inner = [x for x in inner if x]
            if inner:
                out_lines.append(prelude + '{\n' + '\n'.join(inner) + '\n}')
                total += len(inner)
        elif KEY in prelude:
            r = convert_rule(prelude, body)
            if r:
                out_lines.append(r); total += 1
css = '\n'.join(out_lines) + '\n'
open(OUT, 'w', encoding='utf-8').write(css)
print('rules', total, 'bytes', len(css.encode()))

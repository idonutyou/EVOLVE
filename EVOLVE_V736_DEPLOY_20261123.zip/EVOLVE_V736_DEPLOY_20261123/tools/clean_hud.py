from PIL import Image
import numpy as np, cv2, sys
sys.path.insert(0,'/home/claude/work/tools')
from harmonic import harmonic_fill
im=np.array(Image.open('/home/claude/work/art/chamber_clean.png').convert('RGB'))
x0,y0,x1,y1=733,469,823,547
mm=np.zeros(im.shape[:2],bool); mm[y0:y1,x0:x1]=True
mm[y0:484,x0:757]=False      # keep the small text at the panel's top-left
f=im.astype(np.float64).copy()
pad=6; sub=f[y0-pad:y1+pad,x0-pad:x1+pad]; sm=mm[y0-pad:y1+pad,x0-pad:x1+pad]
low=cv2.GaussianBlur(sub,(0,0),1.5)
filled=harmonic_fill(low,sm)
Hh,Ww=sm.shape
syn=np.zeros((Hh,Ww))
for y in [420.1+k*29.39 for k in range(11)]:
    yy=int(round(y))-(y0-pad)
    for o,v in ((-1,0.6),(0,4.0),(1,2.0)):
        if 0<=yy+o<Hh: syn[yy+o,:]+=v
for x in [752,781,811]:
    xx=x-(x0-pad)
    for o,v in ((-1,0.8),(0,3.0),(1,3.0),(2,1.4)):
        if 0<=xx+o<Ww: syn[:,xx+o]+=v
rng=np.random.default_rng(5); g=cv2.GaussianBlur(rng.normal(0,1,(Hh,Ww)),(0,0),0.7); g*=2.0/g.std()
res=filled+(syn+g)[:,:,None]
d=cv2.distanceTransform(sm.astype(np.uint8),cv2.DIST_L2,5); a=np.clip(d/2.0,0,1)[:,:,None]
f[y0-pad:y1+pad,x0-pad:x1+pad]=sub*(1-a)+res*a
out=np.clip(f,0,255).astype(np.uint8)
Image.fromarray(out).save('/home/claude/work/art/chamber_clean2.png')
r=Image.fromarray(out).crop((715,445,840,630)); r=r.resize((r.width*3,r.height*3),Image.LANCZOS); r.save('/home/claude/work/shots/hud_panel_clean.png')

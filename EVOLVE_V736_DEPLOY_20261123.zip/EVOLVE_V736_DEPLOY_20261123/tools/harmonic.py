"""Harmonic (Laplace) fill: masked pixels become the smooth interpolation of their boundary."""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla


def harmonic_fill(img, mask):
    """img: HxWxC float array, mask: HxW bool (True = fill). Returns filled float array."""
    H, W = mask.shape
    out = img.astype(np.float64).copy()
    ys, xs = np.nonzero(mask)
    n = len(ys)
    if n == 0:
        return out
    idx = -np.ones((H, W), np.int64)
    idx[ys, xs] = np.arange(n)
    rows, cols, vals = [], [], []
    C = img.shape[2]
    b = np.zeros((n, C))
    for k, (y, x) in enumerate(zip(ys, xs)):
        cnt = 0
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            yy, xx = y + dy, x + dx
            if yy < 0 or yy >= H or xx < 0 or xx >= W:
                continue
            cnt += 1
            j = idx[yy, xx]
            if j >= 0:
                rows.append(k); cols.append(j); vals.append(-1.0)
            else:
                b[k] += out[yy, xx]
        rows.append(k); cols.append(k); vals.append(float(cnt))
    A = sp.csr_matrix((vals, (rows, cols)), shape=(n, n))
    solve = spla.factorized(A.tocsc())
    for c in range(C):
        out[ys, xs, c] = solve(b[:, c])
    return out

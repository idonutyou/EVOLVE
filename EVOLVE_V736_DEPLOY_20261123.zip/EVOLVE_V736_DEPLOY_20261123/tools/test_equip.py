import sys, json, asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        out={}
        for name,worn in [('cannon+electric',{"arm":"arm_cannon","arm2":"arm_electric"}),('electric+cannon',{"arm":"arm_electric","arm2":"arm_cannon"}),('none',None)]:
            ctx = await b.new_context(viewport={'width':384,'height':832}, is_mobile=True, has_touch=True)
            if worn:
                await ctx.add_init_script("localStorage.setItem('EVOLVE_V575_TEST_PARTS_UI_V523', JSON.stringify({schema:1,worn:%s}))" % json.dumps(worn))
            page = await ctx.new_page()
            await page.goto(sys.argv[1] + '/index.html?evolveUIPage=codex', wait_until='load', timeout=180000)
            await page.wait_for_function("document.querySelector('#codexContent .dex01')!==null", timeout=180000)
            await page.wait_for_timeout(1500)
            out[name]={'snap':await page.evaluate("(()=>{const s=window.__EVOLVE_DUAL_ARM_V631__?.snapshot?.();return s&&[s.arm1,s.arm2]})()"),
                       'parts':await page.evaluate("window.__CLAUDE_CODEX_PARTS__.parts().map(p=>p.ko+':'+p.own)")}
            await ctx.close()
        print(json.dumps(out,ensure_ascii=False,indent=1))
        await b.close()
asyncio.run(main())

/* CLAUDE-CODEX-PARTS-20261123 — codex 파츠 tab.
   The 20 old catalogue parts are replaced by the user's five weapons: 주무기 (베이직 캐논 · 펄스 캐논 ·
   플라즈마 캐논 · 에너지 튜브) and 보조무기 (베이직 캐논 MINI). Weapon pictures are the user's alpha-0 PNGs
   (only the empty margin cut; stored as lossless WebP, pixels identical).
   The list uses the core page's design (same reference picture, same card frames); a tap opens the
   user's detail mock as a full page with the weapon, texts and stats drawn live.
   Display only: no game state, save key, item, equipment or combat value is read for writing or changed.
   Stats are display drafts (marked "수치 조정 중"), not connected to combat. */
(()=>{'use strict';
 const A={{assets_json}};
 const PARTS=[
  {id:'basic_cannon',group:'주무기',ko:'베이직 캐논',en:'BASIC CANNON',type:'탄환',slot:'팔 1',img:A.w_basic,sketch:A.s_basic,glow:'255,140,64',own:'cannon1',
   desc:['가장 기본적인 원거리 무기.','탄환을 1발씩 발사한다.'],st:[14,0.88,330,10,90,85]},
  {id:'pulse_cannon',group:'주무기',ko:'펄스 캐논',en:'PULSE CANNON',type:'펄스',slot:'팔 1',img:A.w_pulse,sketch:A.s_pulse,glow:'214,96,255',own:null,
   desc:['압축 에너지를 사용하는 원거리 무기.','펄스 탄환을 1발씩 발사한다.'],st:[18,0.80,340,30,82,76]},
  {id:'plasma_cannon',group:'주무기',ko:'플라즈마 캐논',en:'PLASMA CANNON',type:'플라즈마',slot:'팔 1',img:A.w_plasma,sketch:A.s_plasma,glow:'70,205,255',own:null,
   desc:['고열 플라즈마를 사용하는 원거리 무기.','플라즈마 탄환을 1발씩 발사한다.'],st:[26,1.10,300,45,70,62]},
  {id:'energy_tube',group:'주무기',ko:'에너지 튜브',en:'ENERGY TUBE',type:'전기',slot:'팔 1',img:A.w_tube,sketch:A.s_tube,glow:'255,192,48',own:'electric',
   desc:['생체 에너지를 응축해 방출하는 원거리 무기.','적 사이를 잇는 연쇄 번개를 발사한다.'],st:[24,0.88,340,20,74,70]},
  {id:'basic_cannon_mini',group:'보조무기',ko:'베이직 캐논 MINI',en:'BASIC CANNON MINI',type:'탄환',slot:'팔 2',img:A.w_mini,sketch:A.s_mini,glow:'255,140,64',own:'cannon2',
   desc:['베이직 캐논의 보조 무기.','탄환을 1발씩 발사하여 추가 공격을 한다.'],st:[5.6,1.08,264,5,95,94]}
 ];
 // display drafts: [공격력, 공격속도(초), 사거리, 관통력, 안정성 %, 에너지 효율 %]
 const STAT=[
  {name:'공격력',fmt:v=>String(v),norm:v=>v/30},
  {name:'공격속도',fmt:v=>v.toFixed(2)+' 초',norm:v=>(1.5-v)/1.1},
  {name:'사거리',fmt:v=>String(v),norm:v=>v/400},
  {name:'관통력',fmt:v=>String(v),norm:v=>v/60},
  {name:'안정성',fmt:v=>v+'%',norm:v=>v/100},
  {name:'에너지 효율',fmt:v=>v+'%',norm:v=>v/100}
 ];
 const BY=Object.fromEntries(PARTS.map(p=>[p.id,p]));
 const st={data:false,rerender:false,cards:0,opened:0,closed:0,errors:[]};
 const note=e=>{if(st.errors.length<12)st.errors.push(String(e&&e.message||e))};
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const $=id=>document.getElementById(id);

 /* 1) codex data: the catalogue the DEX module reads (global lexical bindings of its script) */
 try{
  if(typeof DEX_LIVE_PARTS!=='undefined'&&Array.isArray(DEX_LIVE_PARTS)&&typeof DEX_LIVE_ASSETS==='object'&&DEX_LIVE_ASSETS){
   for(const p of PARTS)DEX_LIVE_ASSETS['claude/parts/'+p.id]=p.img;
   DEX_LIVE_PARTS.splice(0,DEX_LIVE_PARTS.length,...PARTS.map(p=>({id:p.id,slot:p.group,ko:p.ko,en:p.en,rank:'',art:'claude/parts/'+p.id})));
   st.data=true;
   if(document.querySelector('#codexContent [data-dex01]')&&window.EVOLVE_DEX01&&typeof DEX_LIVE_CODEX!=='undefined'){
    window.EVOLVE_DEX01.render({codex:DEX_LIVE_CODEX,parts:DEX_LIVE_PARTS,seen:[],assets:DEX_LIVE_ASSETS});st.rerender=true;
   }
  }
 }catch(e){note(e)}

 function ownership(p){
  if(!p.own)return '미보유';
  let s=null;try{s=window.__EVOLVE_DUAL_ARM_V631__?.snapshot?.()||null;}catch(_){}
  if(s){
   if(p.own==='cannon1'&&s.arm1==='arm_cannon')return '장착 중';
   if(p.own==='cannon2'&&s.arm2==='arm_cannon')return '장착 중';
   if(p.own==='electric'&&(s.arm1==='arm_electric'||s.arm2==='arm_electric'))return '장착 중';
  }
  return '보유';
 }

 /* 2) list cards: same record markup as the core cards (frames 01..05 of the reference) */
 function upgradeCards(){
  const root=document.querySelector('#codexContent .dex01[data-category="parts"]');if(!root)return;
  for(const btn of root.querySelectorAll('#dex01-list button.dex01Card:not(.claudePartRec)')){
   const p=BY[String(btn.dataset.dexCard||'').replace(/^part:/,'')];if(!p)continue;
   const n=PARTS.indexOf(p)+1,no=String(n).padStart(2,'0'),own=ownership(p);
   btn.className='dex01Card dexCoreRecord claudePartRec';
   btn.dataset.referenceCard=String(n);
   btn.setAttribute('aria-label',p.ko+' 상세 정보 · '+own);
   btn.innerHTML=`<span class="dexCoreRecordHeader"><span class="dexCoreRecordNo">${no}</span><span>EVOLVE ARCHIVE</span><span class="dexCoreRecordMark" aria-hidden="true">⌬</span></span><span class="dexCoreRecordBody"><span class="dex01CardArt"><img src="${esc(p.img)}" alt="${esc(p.ko)}" loading="lazy" decoding="async"></span><span class="dexCoreRecordInfo"><span class="dex01CardName">${esc(p.ko)}</span><span class="dex01CardGroup">${esc(p.group)}</span><span class="dexCoreRecordMeta"><span>FILE NO <b>P-${String(n).padStart(3,'0')}</b></span><span>TYPE <b>파츠</b></span><span>STATUS <b data-claude-own>${esc(own)}</b></span></span></span></span><span class="dexCoreRecordFooter"><span>▰ PARTS FILE</span><span aria-hidden="true">▥ ▥ ▥</span></span><span class="claudePartFile" aria-hidden="true">PARTS FILE</span>`;
   st.cards++;
  }
 }
 function refreshOwnership(){
  for(const b of document.querySelectorAll('#codexContent button.claudePartRec')){
   const p=BY[String(b.dataset.dexCard||'').replace(/^part:/,'')];if(!p)continue;
   const own=ownership(p),t=b.querySelector('[data-claude-own]');
   if(t&&t.textContent!==own){t.textContent=own;b.setAttribute('aria-label',p.ko+' 상세 정보 · '+own);}
  }
 }

 /* 3) detail page */
 let el=null,restore=null;
 const poster=()=>$('poster');
 function radarSVG(v){
  const C=[230,1135],R=108,ang=i=>(-90+60*i)*Math.PI/180;
  const P=(i,r)=>[(C[0]+Math.cos(ang(i))*r).toFixed(1),(C[1]+Math.sin(ang(i))*r).toFixed(1)];
  const hex=r=>[0,1,2,3,4,5].map(i=>P(i,r).join(',')).join(' ');
  const rings=[24,48,72].map(r=>`<polygon points="${hex(r)}" fill="none" stroke="rgba(214,246,255,.34)" stroke-width="1.2"/>`).join('');
  const axes=[0,1,2,3,4,5].map(i=>{const q=P(i,96);return `<line x1="${C[0]}" y1="${C[1]}" x2="${q[0]}" y2="${q[1]}" stroke="rgba(214,246,255,.3)" stroke-width="1.1"/>`}).join('');
  const pts=v.map((x,i)=>P(i,96*(0.16+0.84*Math.max(0,Math.min(1,x)))));
  const poly=pts.map(q=>q.join(',')).join(' ');
  const dots=pts.map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="4.6" fill="#fff" stroke="#2fd7e6" stroke-width="1.6"/>`).join('');
  const vtx=[0,1,2,3,4,5].map(i=>{const q=P(i,R);return `<circle cx="${q[0]}" cy="${q[1]}" r="4.4" fill="#fff" stroke="#9fc6d8" stroke-width="1.4"/>`}).join('');
  return `<svg viewBox="46 994 358 286" width="358" height="286" aria-hidden="true" focusable="false"><defs>`+
   `<radialGradient id="cpdPlate" cx="50%" cy="50%" r="55%"><stop offset="0" stop-color="#5fa6c0"/><stop offset=".72" stop-color="#4b8eab"/><stop offset="1" stop-color="#3b7c9c"/></radialGradient>`+
   `<radialGradient id="cpdFill" cx="50%" cy="55%" r="60%"><stop offset="0" stop-color="#2fc9da" stop-opacity=".92"/><stop offset=".75" stop-color="#5ff0f6" stop-opacity=".9"/><stop offset="1" stop-color="#9ffcff" stop-opacity=".95"/></radialGradient>`+
   `<filter id="cpdGlow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`+
   `<filter id="cpdShade" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="3"/></filter></defs>`+
   `<polygon points="${hex(R+3)}" fill="none" stroke="rgba(40,85,115,.28)" stroke-width="7" filter="url(#cpdShade)"/>`+
   `<polygon points="${hex(104)}" fill="url(#cpdPlate)"/>`+
   `<polygon points="${hex(100)}" fill="none" stroke="#2a83a6" stroke-width="2.6"/>`+
   rings+axes+
   `<polygon points="${poly}" fill="url(#cpdFill)" stroke="#e9ffff" stroke-width="3" stroke-linejoin="round" filter="url(#cpdGlow)"/>`+
   `<polygon points="${hex(R)}" fill="none" stroke="#f5fbff" stroke-width="6"/>`+
   `<polygon points="${hex(R+3.4)}" fill="none" stroke="#b8d2e2" stroke-width="1.1"/>`+
   vtx+dots+`</svg>`;
 }
 const LBL=[[230,1010],[356,1066],[361,1195],[232,1262],[101,1195],[101.5,1066]];
 const ROWY=[1015.5,1061,1106,1150.5,1197,1241.5];
 function build(){
  if(el&&el.isConnected)return el;
  const host=poster();if(!host)return null;
  el=document.createElement('section');el.id='claudePartDetail';el.hidden=true;
  el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-labelledby','cpdName');
  const rows=ROWY.map((y,i)=>`<div class="cpdBar" style="top:${y-8.5}px" aria-hidden="true">${'<i></i>'.repeat(14)}</div><b class="cpdVal" style="top:${y-13}px"></b>`).join('');
  const lbls=LBL.map((q,i)=>`<span class="cpdRadarLbl" style="left:${q[0]}px;top:${q[1]}px">${STAT[i].name}</span>`).join('');
  el.innerHTML=`<div class="cpdScroll"><div class="cpdSizer"><div class="cpdStage">`+
   `<div class="cpdSpec"><img alt="" decoding="async"></div><img class="cpdSketch" alt="" aria-hidden="true" decoding="async">`+
   `<div class="cpdTags"><span class="cpdTag cpdTagA"></span><i class="cpdTagSep" aria-hidden="true"></i><span class="cpdTag cpdTagB"></span></div>`+
   `<h3 class="cpdName" id="cpdName"></h3><p class="cpdDesc"></p><span class="cpdDraft">수치 조정 중</span>`+
   `<div class="cpdRadar"></div>${lbls}${rows}`+
   `<span class="cpdFoot cpdFile"></span><span class="cpdFoot cpdSlot"></span><span class="cpdFoot cpdStatus"><i aria-hidden="true"></i><b></b></span>`+
   `<button type="button" class="cpdHit cpdX" aria-label="상세 닫기">닫기</button><button type="button" class="cpdHit cpdClose" aria-label="닫기">닫기</button>`+
   `</div></div></div>`;
  el.addEventListener('click',e=>{if(e.target.closest('.cpdHit')){e.preventDefault();close();}});
  el.addEventListener('keydown',e=>{
   if(e.key==='Tab'){const b=[...el.querySelectorAll('button')];const i=b.indexOf(document.activeElement);
    e.preventDefault();b[(i+(e.shiftKey?b.length-1:1)+b.length)%b.length]?.focus();}
  });
  host.appendChild(el);
  return el;
 }
 function fill(p){
  const n=PARTS.indexOf(p)+1,own=ownership(p);
  const img=el.querySelector('.cpdSpec img');img.src=p.img;img.alt=p.ko;
  el.querySelector('.cpdSpec').style.setProperty('--glow',p.glow);
  el.querySelector('.cpdSketch').src=p.sketch;
  el.querySelector('.cpdTagA').textContent=p.group;el.querySelector('.cpdTagB').textContent=p.type;
  el.querySelector('.cpdName').textContent=p.ko;
  el.querySelector('.cpdDesc').innerHTML=p.desc.map(t=>`<span>${esc(t)}</span>`).join('');
  const v=p.st.map((x,i)=>Math.max(0,Math.min(1,STAT[i].norm(x))));
  el.querySelector('.cpdRadar').innerHTML=radarSVG(v);
  el.querySelectorAll('.cpdBar').forEach((bar,i)=>{const on=Math.max(1,Math.round(v[i]*14));bar.querySelectorAll('i').forEach((c,k)=>c.classList.toggle('on',k<on));});
  el.querySelectorAll('.cpdVal').forEach((b,i)=>{b.textContent=STAT[i].fmt(p.st[i]);});
  el.querySelector('.cpdFile').textContent='P-'+String(n).padStart(3,'0');
  el.querySelector('.cpdSlot').textContent=p.slot;
  const s=el.querySelector('.cpdStatus');s.dataset.own=own==='미보유'?'none':'yes';s.querySelector('b').textContent=own;
  el.setAttribute('aria-label',`${p.ko} · ${p.group} · ${own}`);
 }
 function place(){
  const host=poster(),c=$('homeContentV522');if(!el||!host)return;
  const top=c?c.getBoundingClientRect().top-host.getBoundingClientRect().top:0;
  el.style.setProperty('--cpdTop',Math.max(0,top).toFixed(2)+'px');
 }
 const isOpen=()=>!!(el&&!el.hidden);
 function open(p,from){
  if(!build())return;
  try{fill(p);}catch(e){note(e);return;}
  restore=from||null;el.hidden=false;poster().dataset.claudePartDetail='open';place();
  el.querySelector('.cpdScroll').scrollTop=0;st.opened++;
  requestAnimationFrame(()=>{try{el.querySelector('.cpdClose').focus({preventScroll:true});}catch(_){}});
 }
 function close(){
  if(!isOpen())return;
  el.hidden=true;delete poster().dataset.claudePartDetail;st.closed++;
  const r=restore;restore=null;try{r?.isConnected&&r.focus({preventScroll:true});}catch(_){}
 }

 /* 4) events: parts cards open the page; the codex close button (also used by system Back) closes it first */
 document.addEventListener('click',e=>{
  const t=e.target instanceof Element?e.target:null;if(!t)return;
  if(isOpen()&&t.closest('#codexClose,.codexClose')){e.preventDefault();e.stopImmediatePropagation();close();return;}
  const card=t.closest('#codexContent .dex01[data-category="parts"] [data-dex-card]');if(!card)return;
  const p=BY[String(card.dataset.dexCard||'').replace(/^part:/,'')];if(!p)return;
  e.preventDefault();e.stopImmediatePropagation();open(p,card);
 },true);
 function start(){
  const content=$('codexContent'),host=poster();
  if(content)new MutationObserver(()=>{upgradeCards();if(isOpen()&&!document.querySelector('#codexContent .dex01[data-category="parts"]'))close();})
   .observe(content,{childList:true,subtree:true,attributes:true,attributeFilter:['data-category']});
  if(host)new MutationObserver(()=>{if(host.dataset.homePage!=='codex')close();else refreshOwnership();})
   .observe(host,{attributes:true,attributeFilter:['data-home-page']});
  addEventListener('resize',()=>{if(isOpen())place();});
  upgradeCards();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
 window.__CLAUDE_CODEX_PARTS__=Object.freeze({read:()=>({...st,errors:[...st.errors],open:isOpen()}),parts:()=>PARTS.map(p=>({id:p.id,ko:p.ko,group:p.group,own:ownership(p)})),open:id=>{const p=BY[id];if(p)open(p,null);return !!p;},close});
})();

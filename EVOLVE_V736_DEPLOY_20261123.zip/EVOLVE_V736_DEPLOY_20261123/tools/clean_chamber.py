"""목업 진열장 안의 옛 무기(생체 샘포)와 붉은 빛을 지우고 유리·격자를 다시 채운다.
결과: art/chamber_clean.png (목업 전체 크기 941x1672, 진열장 안쪽만 바뀜)"""
import sys
sys.path.insert(0, '/home/claude/work/tools')
from PIL import Image
import numpy as np, cv2
from harmonic import harmonic_fill

SRC = '/mnt/user-data/uploads/752980c7-image.png'
im = np.array(Image.open(SRC).convert('RGB')).astype(np.float64)
mask = np.load('/home/claude/work/art/weapon_mask.npy')
H, W, _ = im.shape
Y = im.mean(axis=2)

# 1) low frequency from known pixels only (normalized blur), then harmonic fill inside the mask
known = (~mask).astype(np.float64)
sig = 3.0
num = np.stack([cv2.GaussianBlur(im[:, :, c] * known, (0, 0), sig) for c in range(3)], 2)
den = cv2.GaussianBlur(known, (0, 0), sig)[:, :, None]
low = num / np.maximum(den, 1e-6)
low[~mask] = np.stack([cv2.GaussianBlur(im[:, :, c], (0, 0), sig) for c in range(3)], 2)[~mask]
y0, y1, x0, x1 = 395, 725, 190, 745
sub = low[y0:y1, x0:x1].copy()
fill = harmonic_fill(sub, mask[y0:y1, x0:x1])
low[y0:y1, x0:x1] = fill

# 2) high frequency: measured grid lines + fine grain
hp = Y - cv2.GaussianBlur(Y, (0, 0), sig)
glass = (~mask) & (np.arange(H)[:, None] >= 404) & (np.arange(H)[:, None] < 716) & \
        (np.arange(W)[None, :] >= 205) & (np.arange(W)[None, :] < 730)


def line_profile(axis, centers, lo, hi):
    """average hp profile across a line (offsets -3..3) using known glass pixels"""
    prof = np.zeros(7); cnt = np.zeros(7)
    for c in centers:
        ci = int(round(c))
        for o in range(-3, 4):
            if axis == 'h':
                yy = ci + o
                if yy < 0 or yy >= H: continue
                sel = glass[yy, lo:hi]
                if sel.sum() < 8: continue
                prof[o + 3] += hp[yy, lo:hi][sel].mean(); cnt[o + 3] += 1
            else:
                xx = ci + o
                sel = glass[lo:hi, xx]
                if sel.sum() < 8: continue
                prof[o + 3] += hp[lo:hi, xx][sel].mean(); cnt[o + 3] += 1
    return prof / np.maximum(cnt, 1)


hy = [420.1 + k * 29.39 for k in range(0, 11)]
hy = [y for y in hy if 404 <= y < 716]
vx = [221, 250, 280, 309, 337, 366, 394, 424, 452, 481, 512, 544, 572, 601, 630, 658, 690, 722]
ph = line_profile('h', hy, 205, 730)
pv = line_profile('v', vx, 404, 716)
ph -= ph[[0, 6]].mean(); pv -= pv[[0, 6]].mean()
print('h profile', np.round(ph, 2), 'v profile', np.round(pv, 2))

syn = np.zeros((H, W))
for y in hy:
    for o in range(-3, 4):
        yy = int(round(y)) + o
        syn[yy, :] += ph[o + 3]
for x in vx:
    for o in range(-3, 4):
        syn[:, x + o] += pv[o + 3]
# grain: residual noise level of clean glass away from lines
near = np.zeros((H, W), bool)
for y in hy: near[int(round(y)) - 3:int(round(y)) + 4, :] = True
for x in vx: near[:, x - 3:x + 4] = True
res = hp[glass & ~near]
rs = float(1.4826*np.median(np.abs(res-np.median(res))))
rng = np.random.default_rng(7)
grain = cv2.GaussianBlur(rng.normal(0, 1, (H, W)), (0, 0), 0.7)
grain *= rs / grain.std() * 0.9
print('grain std', round(rs, 2))
hp_syn = syn + grain

# 3) compose with a soft edge at the mask boundary
dist = cv2.distanceTransform(mask.astype(np.uint8), cv2.DIST_L2, 5)
alpha = np.clip(dist / 3.0, 0, 1)[:, :, None]
filled = low + hp_syn[:, :, None]
out = im * (1 - alpha) + filled * alpha
out = np.clip(out, 0, 255).astype(np.uint8)
Image.fromarray(out).save('/home/claude/work/art/chamber_clean.png')
Image.fromarray(out[380:740, 120:820]).save('/home/claude/work/shots/chamber_clean_crop.png')
print('saved')

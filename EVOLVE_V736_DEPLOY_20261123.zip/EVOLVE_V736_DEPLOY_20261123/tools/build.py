"""V736 빌드: 기준(V735) 작업본에서 index.html·version.json·asset-manifest.json을 만들고 새 그림을 더한다.
python3 build.py <base_repo_dir> <out_dir>
out_dir/files/ 에 바뀌는 파일 3개 + assets/ 새 그림, out_dir/site/ 에 시험용 전체 사이트(나머지는 심볼릭 링크)."""
import json, os, re, sys, shutil, subprocess, hashlib
from PIL import Image
import numpy as np

BASE, OUT = sys.argv[1], sys.argv[2]
W = '/home/claude/work'
BUILD_OLD, BUILD_NEW = 'V735-CLAUDE-UI-20261122', 'V736-CLAUDE-CODEX-PARTS-20261123'
assets = json.load(open(f'{W}/art/assets.json'))
html = open(f'{BASE}/index.html', encoding='utf-8').read()
assert html.count('"build":"' + BUILD_OLD + '"') == 1, 'base build string'
assert 'claudeCodexPartsV736' not in html

# 1) parts list css (core list rules duplicated for the parts tab)
subprocess.run(['python3', f'{W}/tools/gen_parts_css.py', f'{BASE}/index.html', f'{W}/art/parts_list.css'], check=True)
gen = open(f'{W}/art/parts_list.css', encoding='utf-8').read()

# 2) floor colours under the detail picture (last row of the template, 21 stops)
t = np.array(Image.open(f'{W}/art/detail_template_full.png').convert('RGB')).astype(int)
row = t[1671]
stops = ','.join('rgb(%d,%d,%d) %.1f%%' % (*row[max(0, x - 4):x + 5].mean(0).round().astype(int), x / 940 * 100) for x in range(0, 941, 47))

css = open(f'{W}/src/parts.css', encoding='utf-8').read()
css = css.replace('{{tabs_parts}}', assets['tabs_parts']['path']).replace('{{detail_bg}}', assets['detail_bg']['path']).replace('{{floor_stops}}', stops)
js = open(f'{W}/src/parts.js', encoding='utf-8').read()
amap = {k: v['path'] for k, v in assets.items()}
js = js.replace('{{assets_json}}', json.dumps(amap, separators=(',', ':')))
assert '{{' not in css and '{{' not in js

block = ('<style id="claudeCodexPartsV736">\n'
         '/* CLAUDE-CODEX-PARTS-20261123 — codex 파츠 tab drawn like the core tab (same reference picture and card\n'
         '   frames; rules below are the core list rules re-targeted at data-category="parts"), then the parts-only\n'
         '   tab strip, card footer and the weapon detail page. Core tab styling is untouched. */\n'
         + gen + css + '</style>\n<script id="claudeCodexPartsLogicV736">\n' + js + '</script>\n')
i = html.rindex('</body></html>')
html2 = html[:i] + block + html[i:]
html2 = html2.replace('"build":"' + BUILD_OLD + '"', '"build":"' + BUILD_NEW + '"')
old_n = json.load(open(f'{BASE}/version.json'))['assets']
new_n = old_n + len(assets)
assert html2.count('"assets":%d' % old_n) == 1
html2 = html2.replace('"assets":%d' % old_n, '"assets":%d' % new_n)

# 3) version.json / asset-manifest.json (same formatting as the originals)
vtxt = open(f'{BASE}/version.json', encoding='utf-8').read()
v = json.loads(vtxt)
assert json.dumps(v, indent=2, ensure_ascii=False) + '\n' == vtxt or json.dumps(v, indent=2, ensure_ascii=False) == vtxt.rstrip('\n'), 'version.json format'
v['build'] = BUILD_NEW; v['assets'] = new_n
vout = json.dumps(v, indent=2, ensure_ascii=False) + ('\n' if vtxt.endswith('\n') else '')
mtxt = open(f'{BASE}/asset-manifest.json', encoding='utf-8').read()
m = json.loads(mtxt)
fmt = lambda obj: json.dumps(obj, indent=2, ensure_ascii=False) + ('\n' if mtxt.endswith('\n') else '')
assert fmt(m) == mtxt, 'manifest format'
have = {e['path'] for e in m}
for k, a in assets.items():
    assert a['path'] not in have
    m.append({'bytes': a['bytes'], 'kind': 'image', 'path': a['path'], 'sha256': a['sha256']})
assert len(m) == new_n, (len(m), new_n)
mout = fmt(m)

# 4) outputs
files = f'{OUT}/files'
if os.path.exists(OUT): shutil.rmtree(OUT)
os.makedirs(f'{files}/assets')
open(f'{files}/index.html', 'w', encoding='utf-8').write(html2)
open(f'{files}/version.json', 'w', encoding='utf-8').write(vout)
open(f'{files}/asset-manifest.json', 'w', encoding='utf-8').write(mout)
for k, a in assets.items():
    shutil.copy(f'{W}/build_assets/' + os.path.basename(a['path']), f'{files}/' + a['path'])
    assert hashlib.sha256(open(f'{files}/' + a['path'], 'rb').read()).hexdigest() == a['sha256']
site = f'{OUT}/site'
os.makedirs(f'{site}/assets')
for name in os.listdir(BASE):
    if name in ('.git', 'assets', 'index.html', 'version.json', 'asset-manifest.json'): continue
    os.symlink(f'{BASE}/{name}', f'{site}/{name}')
for name in os.listdir(f'{BASE}/assets'):
    os.symlink(f'{BASE}/assets/{name}', f'{site}/assets/{name}')
for f in ('index.html', 'version.json', 'asset-manifest.json'):
    shutil.copy(f'{files}/{f}', f'{site}/{f}')
for k, a in assets.items():
    shutil.copy(f'{files}/' + a['path'], f'{site}/' + a['path'])
print('index bytes', len(html2.encode()), 'block bytes', len(block.encode()), 'assets', old_n, '->', new_n)

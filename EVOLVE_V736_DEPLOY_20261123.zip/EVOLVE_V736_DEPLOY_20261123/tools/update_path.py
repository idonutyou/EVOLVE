"""V735 -> V736 업데이트 경로: 같은 주소에서 V735로 연 뒤 파일을 V736으로 바꾸고, 업데이트 안내·적용·저장 유지 확인."""
import json, os, asyncio, hashlib
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8767'
LINK='/home/claude/work/upd'
def swap(target):
    tmp=LINK+'.tmp'; os.symlink(target,tmp); os.replace(tmp,LINK)
SNAP="""()=>{const o={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);o[k]=localStorage.getItem(k);}return o;}"""
async def main():
    swap('/home/claude/idonutyou/evolve')
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        ctx=await b.new_context(viewport={'width':384,'height':832},is_mobile=True,has_touch=True)
        await ctx.add_init_script("if(!localStorage.getItem('EVOLVE_V575_TEST_PARTS_UI_V523'))localStorage.setItem('EVOLVE_V575_TEST_PARTS_UI_V523', JSON.stringify({schema:1,worn:{arm:'arm_cannon',arm2:'arm_electric'}}))")
        page=await ctx.new_page(); errs=[]
        page.on('pageerror',lambda e:errs.append(str(e)[:200]))
        await page.goto(BASE+'/index.html',wait_until='load',timeout=180000)
        await page.wait_for_function("window.EVOLVE_WEB_CONFIG && document.getElementById('poster')",timeout=180000)
        await page.wait_for_timeout(9000)
        r={'atHome_before':await page.evaluate('!!window.EVOLVE_WEB_GUARD?.atHome?.()')}
        r['before_build']=await page.evaluate("window.EVOLVE_WEB_CONFIG.build")
        before=await page.evaluate(SNAP)
        swap('/home/claude/work/out736/site')
        await page.evaluate("dispatchEvent(new Event('online'))")
        await page.wait_for_timeout(3500)
        r['notice_visible']=await page.evaluate("(()=>{const e=document.getElementById('webUpdate');return !!e&&!e.hidden})()")
        await page.evaluate("document.getElementById('webApply')?.click()")
        await page.wait_for_load_state('load',timeout=180000)
        await page.wait_for_function("window.EVOLVE_WEB_CONFIG && document.getElementById('poster')",timeout=180000)
        await page.wait_for_timeout(4000)
        r['after_build']=await page.evaluate("window.EVOLVE_WEB_CONFIG.build")
        await page.evaluate("dispatchEvent(new Event('online'))"); await page.wait_for_timeout(2500)
        r['notice_after']=await page.evaluate("(()=>{const e=document.getElementById('webUpdate');return !!e&&!e.hidden})()")
        after=await page.evaluate(SNAP)
        game=lambda d:{k:v for k,v in d.items() if k.startswith('EVOLVE')}
        bk=set(game(before)); ak=set(game(after))
        r['save_keys_before']=len(bk); r['save_keys_after']=len(ak)
        r['changed_keys']=[k for k in bk&ak if before[k]!=after[k]]
        r['new_keys']=sorted(ak-bk); r['lost_keys']=sorted(bk-ak)
        r['parts_state_kept']=before.get('EVOLVE_V575_TEST_PARTS_UI_V523')==after.get('EVOLVE_V575_TEST_PARTS_UI_V523')
        r['parts_before']=before.get('EVOLVE_V575_TEST_PARTS_UI_V523'); r['parts_after']=after.get('EVOLVE_V575_TEST_PARTS_UI_V523')
        r['codex_parts']=await page.evaluate("window.__CLAUDE_CODEX_PARTS__ && window.__CLAUDE_CODEX_PARTS__.parts().map(p=>p.ko+':'+p.own)")
        r['errors']=errs
        print(json.dumps(r,ensure_ascii=False,indent=1))
        await b.close()
    swap('/home/claude/idonutyou/evolve')
asyncio.run(main())
